<?php
namespace Home\Model;
use Think\Model;
use Think\Verify;
class UserModel extends Model
{
    public $_validate = array(
        array('user_name','require','用户名不能为空！'),
        array('user_name','6,20','用户名格式不正确！',1,'length'),
        array('password','6,20','密码格式不正确！',1,'length'),
        array('verify','verifyCheck','验证码不正确！',1,'callback '),
    );
    //校验验证码
    public function verifyCheck($code,$id=''){
        $verify = new Verify();
        $bool = $verify->check($code,$id);
        return $bool;
    }
}